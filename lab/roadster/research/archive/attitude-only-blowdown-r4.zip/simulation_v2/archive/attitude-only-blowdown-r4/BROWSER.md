# 浏览器物理实验 · r4

官方 MuJoCo 3.15.0 WASM 每 2 ms 积分，控制器每 20 ms 读取当前状态并更新喷口。改初态后重新计算，不用预录轨迹决定位姿。

- `frame.pos` 是整车重心。静止离地 0.50 m、前后 50:50 是假设；车壳惯性中心随气量补偿轮体质量，整车重心与惯量已做 native/WASM 对照。
- 保留竖直起降及姿态控制，没有水平速度或位置目标。风机的轴向反作用保留。
- 全程供气衰减：`P/P0=(m/m0)^1.2`、`Isp/Isp0=(m/m0)^0.1`，没有恒压平台。
- 允许向前滚动着陆。完成动作且无车身碰地或冲击超限后，至少三轮接触连续 1 秒；竖直速度 <0.3 m/s、侧滑 <0.3 m/s、轮胎接触滑移 <0.5 m/s、角速 <0.2 rad/s、倾角 <8°。

```js
const engine = await loadEngine('./vendor/mujoco/mujoco.js');
const sim = await createSimulation(config, parameters, initialCase, {
  engine, xml: worldXml, policyId: 'final'
});
const frame = sim.step(1); // 一个控制周期
sim.applyImpulse([0, 2000, 0]); // 下一物理子步在整车重心施加 N·s 冲量
sim.reset(newCase, parameters, {policyId: 'untuned'});
sim.dispose();
```

初态使用米、秒、弧度，`quat` 为 w,x,y,z；`vel` 为世界坐标，`omega` 为车体坐标。穿地初态和恒压供气模式会报错。`snapshot()` 返回接触、实际喷力、气量、轮速、水平冲量和控制误差；`done/status` 表示结束及原因。

运行 `node simulation_v2/test-browser-runtime.mjs` 查看双引擎验收，运行 `node simulation_v2/benchmark_timing.mjs` 实测当前最终策略耗时。报告核对源码和策略哈希，旧 r3 成功率及耗时不能代表 r4。第 18 代最终策略的 19 项双引擎对照通过，但三项标准飞行仍分别出现车身碰地、车身碰地和冲击超限；这证明数值一致，不证明控制成功，也不能证明物理上不可能。最新计时见 timing-benchmark.json，失败轨迹也如实计入。

这仍是假设 12 个喷口、简化轮胎和平地的实验；外观网格不参与碰撞，传感器使用理想状态。Node 耗时不保证浏览器或实车的最坏执行时间。
