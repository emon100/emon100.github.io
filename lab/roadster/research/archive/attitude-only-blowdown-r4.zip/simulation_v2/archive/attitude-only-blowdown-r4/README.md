# 接触世界与真实参数学习

MuJoCo 3.15.0，每 2 ms 积分、20 ms 控制。CEM 学习同一套任务条件反馈策略的 14 个参数，保留未调参和人工基线。动作按高度、姿态、角速度及接触切换，没有预设姿态动画。固定开发集 12 例中 2 例也用于训练；最终 120 例任务留出和 80 例 SO(3) 留出不参与选择。

喷口只控制姿态和竖直起降，没有水平速度或位置反馈，也不抵消风扇水平反作用。分配器共同缩放请求力和力矩，保持竖直目标方向；阀门滞后、车辆转动仍可能产生水平残差，记录在 `jetForceWorld` 与水平冲量中。气压从首次耗气开始下降，采用 P/P₀=(m/m₀)^1.2、Isp/Isp₀=(m/m₀)^0.1，不提供稳压模式。

`pos` 是整车质心。平地质心高 0.50 m、前后居中，车壳惯性中心补偿四轮质量，燃料假设位于整车质心。4.10 × 1.72 × 1.20 m 尺寸、质量、惯量、260 kg 气量、12 个单向喷口及全部推力、功率均是实验假设，不是 Tesla 实车参数。风扇压差与轴向排气共用功率，离地后吸附消失。四个被动转动轮保留切向和扭转摩擦，以铰链阻尼模拟转动损耗，没有真实悬架或橡胶模型。

成功须完成动作且没有车身触地或超限冲击，随后持续 1 秒至少三轮接触。每个物理步检查倾角 <8°、角速 <0.20 rad/s、竖直速度和侧向速度各 <0.30 m/s、轮胎接地点滑移 <0.50 m/s。允许向前滚动，不要求刹停或回到起点。此验收不是实车安全证明。

```sh
.venv/bin/python test_core.py
.venv/bin/python train.py
.venv/bin/python export_parity.py && node test_controller.mjs
.venv/bin/python run_case.py --task moving_recovery --height 8 --vx 4 --roll 150 --pitch 20 --policy final
```

`results.json` 保存同初态对照、训练曲线、留出及失败；`policies.json` 保存参数和源码指纹。敏感性测试包括关闭四个喷口、推力八折、初始充气量八折。`world.xml` 与 `controller.mjs` 供浏览器复算。自由 SO(3) 低高度初态抬到不穿地的最小高度 +2 cm，并记录实际初值。旧 r3 完整保存在 `archive/contact-grip-r3/`，新旧成绩不可直接比较。失败只否定这套配置和当前搜索得到的策略，不能证明该初态在所有控制算法下都不可达。

依据：[MuJoCo 接触动力学](https://mujoco.readthedocs.io/en/stable/computation/index.html)。
