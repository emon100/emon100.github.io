# Roadster 研究与训练

先看[物理与证据](physics.md)、[尺度估计](measurement.md)，再看[当前 r4 试验](simulation-v2.md)与[检查结果](verification.md)。

- [素材](media.md)：两段1080p视频、10张高清帧、官方图片。
- [外形参考](model-reference.md)：官网多视角与原型区别。
- [风扇专利](fan-patents.md) / [低重心依据](ev-cg-sources.md)。
- [视频计划](content-plan.md)：90秒分镜。
- [原文入口](transcript-index.md) / [四版本评审](cross-review.md)。
- [着色模型、排气与控制时序](materials-and-control.md)：材质来源、r4控制范围与本机耗时。

当前入口为 `lab.html`，车模比较为 `model.html`。r4采用14参数、全程降压供气和0.50 m重心假设，允许纵向滚动着陆。两项完整滚转留出均未成功，倒置回正为3/40；这说明本次配置与策略表现有限，不能证明动作物理上不可行。

旧版训练在 `training.html`。[r3存档](archive/contact-grip-r3.zip)保留旧说明、源码与结果，旧成功率与耗时不作为当前结论。所有尺寸、质量和执行器配置均按证据或假设标注，仿真不代表Tesla实车性能。
