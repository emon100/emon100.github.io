# Roadster 研究与飞行试验

- 网站源文件在 `site/dist/`，当前入口 `lab.html`，车模比较 `model.html`。
- 原片、高清帧、官网图在 `media/`；来源见 `research/README.md`。
- 车模、输入依据和导出验证在 `models/`；Meshy手动模型已去墙，此前CLI请求未生成。
- MuJoCo世界、14参数控制器、22代CEM搜索与留出评估在 `simulation_v2/`，该目录README给出复现方式。
- `roadster-research-package.zip`为离线网站及复现代码包。旧试验和中间版本保留在各目录 `archive/`。

当前版本 `attitude-only-blowdown-r4` 选择第18代，共4,939次训练与评估。任务留出为0/40、0/40、3/40，自由姿态为0/80；1 ms复算中回正变为2/40，存在边界敏感。这些失败对应本次假设和策略，不能证明物理不可行或Tesla实车能力。

r4采用全程降压、0.50 m整车CG假设，仅控制姿态与竖直运动，允许纵向滚动着陆。尺寸、质量及12喷口布局均未获实车标定。完整说明见 `research/simulation-v2.md`，检查见 `research/verification.md`。

[私有站入口](https://roadster-physics-studio.dohuuphong62.chatgpt.site/lab.html)

当前着色模型为 `models/meshy/materials-reviewed/roadster-meshy-colored.glb`；材质、排气与耗时说明见 `research/materials-and-control.md`。旧版源码、结果与文档见[r3存档](research/archive/contact-grip-r3.zip)。
