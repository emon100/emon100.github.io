import unittest, copy
import numpy as np
from core import *

class PhysicsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cfg=load_config()
    def test_settle_fan_increases_real_wheel_load_instead_of_being_canceled(self):
        w=World(self.cfg);c=default_case('stationary_kickflip',self.cfg);w.reset(c)
        for _ in range(25):w.advance(np.zeros(12),0)
        base_load=w.contact['totalNormalForce'];params=HANDCRAFTED.copy();params[-1]=.8;p=FeedbackPolicy(params,c['task'],c,self.cfg);p.phase='settle';p.turn_complete=True;p.was_airborne=True
        for _ in range(25):
            st=w.state();force,torque,fc=p.command(st,w.contact);fan=fan_model(st['pos'],st['R'],fc,self.cfg);requested=np.r_[st['R'].T@(force-fan['axialForce']),torque-st['R'].T@fan['torqueWorld']];u,a=w.allocate(requested);w.advance(u,fc,{'task':c['task'],'initialXY':[0,0],'turnComplete':True,'wasAirborne':True})
        suction=-w.fan['suctionForce'][2];self.assertGreater(suction,3000.);self.assertGreater(w.contact['totalNormalForce'],base_load+suction*.8)
        actual_jet=w.A@w.forces;self.assertLess(abs(actual_jet[2]+w.fan['axialForce'][2]),5.);self.assertLess(actual_jet[2],suction*.05)
    def test_free_fall_and_mass_update_do_not_reset_state(self):
        w=World(self.cfg);c=default_case('moving_recovery',self.cfg);c.update(pos=[1.,2.,15.],quat=[1.,0.,0.,0.],vel=[2.,0.,0.]);w.reset(c)
        for _ in range(10):w.advance(np.zeros(12),0)
        s=w.state();self.assertAlmostEqual(s['pos'][0],1.4,delta=1e-5);self.assertAlmostEqual(s['vel'][2],-1.962,places=5);self.assertLess(abs(s['pos'][2]-(15-.5*9.81*.2**2)),.003)
    def test_layout_and_pure_couple(self):
        report=controllability(self.cfg);self.assertEqual(report['rank'],6);self.assertTrue(report['positiveNullExists'])
        ns=nozzle_layout(self.cfg);limits=np.array([n['maxForce'] for n in ns]);target=np.array([0.,0.,0.,1000.,0.,0.]);f=allocate_fixed_nozzles(target,limits,self.cfg)
        np.testing.assert_allclose(wrench_matrix(ns)@f,target,atol=1e-6);self.assertTrue(np.all(f>=0));self.assertTrue(np.all(f<=limits))
        for axis in range(6):
            for sign in [-1,1]:
                target=np.eye(6)[axis]*sign*1000;f=allocate_fixed_nozzles(target,limits,self.cfg);np.testing.assert_allclose(wrench_matrix(ns)@f,target,atol=1e-6)
    def test_disabled_downward_jets_cannot_supply_negative_z(self):
        w=World(self.cfg);c=default_case('moving_recovery',self.cfg);c['disabled_nozzles']=['J02','J04','J06','J08'];w.reset(c);u,a=w.allocate(np.array([0,0,-20000,0,0,0]));self.assertAlmostEqual(a['achievedWrenchBody'][2],0.,places=5);self.assertTrue(all(u[i]==0 for i in [1,3,5,7]))
    def test_fuel_empty_produces_no_jet_impulse(self):
        w=World(self.cfg);c=default_case('moving_recovery',self.cfg);c.update(fuel=0.,quat=[1.,0.,0.,0.],vel=[0.,0.,0.]);w.reset(c);s=w.advance(np.ones(12),0)
        self.assertEqual(float(w.forces.sum()),0.);self.assertLess(s['vel'][2],-.19);self.assertEqual(w.fuel,0.)
    def test_fan_seal_and_power_budget(self):
        near=fan_model(np.array([0.,0.,.68]),np.eye(3),1,self.cfg);far=fan_model(np.array([0.,0.,4.]),np.eye(3),1,self.cfg)
        self.assertLess(near['suctionForce'][2],0);self.assertEqual(float(np.linalg.norm(far['suctionForce'])),0.);self.assertLess(far['axialForce'][2],0.)
        for f in [near,far]:self.assertLessEqual(f['power'],f['availableFluidPower']+1e-6)
    def test_passive_wheels_preserve_initial_rolling_speed(self):
        w=World(self.cfg);c=default_case('moving_kickflip',self.cfg);w.reset(c)
        for _ in range(10):s=w.advance(np.zeros(12),0)
        self.assertGreater(s['vel'][0],4.8);self.assertFalse(w.any_body_contact)
    def test_contact_is_not_success_until_one_second_stable(self):
        r=rollout('stationary_kickflip',HANDCRAFTED,default_case('stationary_kickflip',self.cfg),self.cfg,record=True,policy_id='handcrafted')
        self.assertTrue(r['success']);self.assertGreaterEqual(r['metrics']['stableSeconds'],1.);self.assertFalse(r['metrics']['hardContact']);self.assertFalse(r['metrics']['bodyContact'])
        landed=[f for f in r['frames'] if f['contact']['wheelCount']>=3 and f['goal'].get('turnComplete')]
        self.assertGreater(r['frames'][-1]['t']-landed[0]['t'],.95)
    def test_low_inverted_case_fails_instead_of_snapping_upright(self):
        c=default_case('moving_recovery',self.cfg);c['pos'][2]=.80;c['vel'][2]=-4.
        r=rollout('moving_recovery',HANDCRAFTED,c,self.cfg,record=True,policy_id='handcrafted');self.assertFalse(r['success']);self.assertIn(r['status'],['body_contact','hard_contact']);self.assertLess(r['metrics']['duration'],1.)
    def test_no_control_inverted_body_falls_and_hits_floor(self):
        r=rollout('moving_recovery',UNTUNED,default_case('moving_recovery',self.cfg),self.cfg,record=True,policy_id='no_control')
        self.assertFalse(r['success']);self.assertTrue(r['metrics']['bodyContact']);self.assertEqual(r['metrics']['fuelUsed'],0.);self.assertGreater(r['metrics']['maxContactClosingSpeed'],10.)
    def test_actual_mujoco_sites_match_the_published_nozzle_wrenches(self):
        w=World(self.cfg);A=wrench_matrix(nozzle_layout(self.cfg))
        for q in [euler_q(0,0,0),euler_q(math.pi/2,0,0),euler_q(.3,.2,1.1)]:
            c=default_case('moving_recovery',self.cfg);c.update(pos=[0,0,15],quat=q.tolist(),vel=[0,0,0],omega=[0,0,0]);w.reset(c)
            for j in range(12):
                w.data.ctrl[:]=0;w.data.ctrl[j]=1000;mujoco.mj_forward(w.model,w.data);expected=np.r_[qmat(q)@A[:3,j]*1000,A[3:,j]*1000];np.testing.assert_allclose(w.data.qfrc_actuator[:6],expected,atol=1e-8)
    def test_impossible_dry_inertia_is_rejected(self):
        c=default_case('moving_recovery',self.cfg);c.update(mass=100.,fuel=0.)
        with self.assertRaises(ValueError):World(self.cfg).reset(c)
    def test_geometry_and_nozzle_exits_are_consistent(self):
        v=self.cfg['vehicle'];top=max(b['position'][2]+b['half_size'][2] for b in v['collision_boxes']);self.assertAlmostEqual(top-v['wheel_z']+v['wheel_radii'][2],1.20)
        for n in nozzle_layout(self.cfg):
            p=np.array(n['position'])
            for b in v['collision_boxes']:self.assertFalse(np.all(np.abs(p-b['position'])<np.array(b['half_size'])))
            for x in [-v['axle_half'],v['axle_half']]:
                for y in [-v['track_half'],v['track_half']]:self.assertGreater(np.sum(((p-[x,y,v['wheel_z']])/v['wheel_radii'])**2),1.)
    def test_free_inputs_reject_negative_fuel_or_force_scaling(self):
        for key in ['fuel','thrust_scale']:
            c=default_case('moving_recovery',self.cfg);c[key]=-1
            with self.assertRaises(ValueError):World(self.cfg).reset(c)
    def test_stability_counter_resets_on_actual_loss_of_contact(self):
        w=World(self.cfg);c=default_case('stationary_kickflip',self.cfg);w.reset(c);context={'task':c['task'],'initialXY':[0,0],'turnComplete':True,'wasAirborne':True}
        for _ in range(20):w.advance(np.zeros(12),0,context)
        self.assertGreater(w.stable_seconds,.3)
        up=np.zeros(12);up[::2][:4]=1.
        for _ in range(6):w.advance(up,0,context)
        self.assertEqual(w.stable_seconds,0.);self.assertEqual(w.contact['minimumWheelCount'],0)
    def test_reward_is_accounted_and_finite(self):
        r=rollout('stationary_kickflip',HANDCRAFTED,default_case('stationary_kickflip',self.cfg),self.cfg,record=True,policy_id='handcrafted')
        finite(r);self.assertAlmostEqual(sum(f['reward']['instant'] for f in r['frames']),r['metrics']['score'],places=7)

if __name__=='__main__':unittest.main(verbosity=2)
