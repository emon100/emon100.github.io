"""Audit emitted records and recompute a small paired timestep sensitivity set."""
import argparse, copy, hashlib, json
from core import *

def all_rollouts(data):
    for task,report in data['tasks'].items():
        for name,r in report['comparisons'].items():yield f'{task}/{name}',r
        for i,r in enumerate(report.get('failureExamples',[])):yield f'{task}/failure{i}',r
    if data.get('freeFailureExample'):yield 'free/failure',data['freeFailureExample']

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--results',default=str(HERE/'results.json'));parser.add_argument('--steps',action='store_true');args=parser.parse_args();data=json.loads(Path(args.results).read_text());finite(data);assert data['status']=='complete';cfg=data['config'];assert data['engine']['version']==mujoco.__version__=='3.15.0'
    nozzles=nozzle_layout(cfg);count=0;worst_fuel_error=0.;maximum_bound_excess=0.;comparisons=0
    for label,r in all_rollouts(data):
        fuel0=r['case'].get('fuel',cfg['fuel']['initial_kg']);previous=None
        for f in r['frames']:
            count+=1;assert abs(np.linalg.norm(f['quat'])-1)<1e-6,label
            assert len(f['nozzleForces'])==12 and all(x>=-1e-9 for x in f['nozzleForces'])
            limits=np.array([n['maxForce'] for n in nozzles])*f['pressureScale']*r['case'].get('thrust_scale',1.)
            for i,n in enumerate(nozzles):
                if n['id'] in r['case'].get('disabled_nozzles',[]):limits[i]=0.
            excess=float(np.max(np.array(f['nozzleForces'])-limits));maximum_bound_excess=max(maximum_bound_excess,excess);assert excess<1e-6,(label,excess)
            assert sum(f['nozzleForces'])<=cfg['actuators']['total_force_max']*f['pressureScale']*r['case'].get('thrust_scale',1.)+1e-6
            fuel_error=abs(f['fuel']+f['fuelUsed']-fuel0);worst_fuel_error=max(worst_fuel_error,fuel_error);assert fuel_error<1e-6
            assert f['fan']['power']<=f['fan']['availableFluidPower']+1e-5
            if previous:
                assert f['t']>previous['t'];assert f['fuel']<=previous['fuel']+1e-9
                assert f['contact']['stableSeconds']<=previous['contact']['stableSeconds']+(f['t']-previous['t'])+1e-8
            previous=f
        if r['success']:
            assert r['frames'][-1]['contact']['stableSeconds']+1e-9>=cfg['landing']['stable_seconds'];assert not r['metrics']['hardContact'];assert not r['metrics']['bodyContact'];assert r['metrics']['turnComplete']
        comparisons+=1
    for task,report in data['tasks'].items():
        cases=[r['case'] for r in report['comparisons'].values()];assert all(c==cases[0] for c in cases[1:]),task
        ref=[r['case'] for r in report['holdout']['episodes']]
        for name,baseline in report['baselineEvaluation'].items():assert [r['case'] for r in baseline['episodes']]==ref,(task,name)
    audit={'engine':mujoco.__version__,'rolloutsAudited':comparisons,'framesAudited':count,'maxFuelAccountingError':worst_fuel_error,'maxNozzleLimitExcess':maximum_bound_excess,'pairedCaseComparison':'passed','allValuesFinite':True,'sourceMatches':data['sourceSha256']==hashlib.sha256((HERE/'core.py').read_bytes()).hexdigest()}
    if args.steps:
        from concurrent.futures import ProcessPoolExecutor
        from train import init_worker, evaluate_job
        params=data['tasks'][TASKS[0]]['policies']['final']['parameters'];rows=[]
        for task in TASKS:
            cases=[e['case'] for e in data['tasks'][task]['holdout']['episodes']];baseline=[e['success'] for e in data['tasks'][task]['holdout']['episodes']];fine=copy.deepcopy(cfg);fine['physics']['dt']=.001
            with ProcessPoolExecutor(max_workers=4,initializer=init_worker,initargs=(fine,)) as pool:
                reruns=[r for batch in pool.map(evaluate_job,[(params,cases[i:i+4],'final') for i in range(0,len(cases),4)]) for r in batch]
            rows.append({'task':task,'dt':.001,'cases':len(cases),'successes':sum(r['success'] for r in reruns),'changedClassifications':sum(r['success']!=a for r,a in zip(reruns,baseline)),'statuses':[r['status'] for r in reruns]})
        audit['stepSensitivity']=rows
    write_json(HERE/'audit.json',audit);print(json.dumps(audit,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
