# 接触世界与真实参数学习

MuJoCo **3.15.0**，2 ms 物理步、20 ms 控制步，四个被动轮铰链。所有姿态由引擎计算；状态反馈按升空、滚转/回正、制动下降、接触稳定切换，无时间预设姿态轨迹。CEM 学习同一套任务条件控制器的 15 个参数，人工基线独立保留。固定开发评估集12例中2例也用于训练；最终120例任务留出和80例SO(3)留出均未参与训练或选策略。

**这是 12 个固定单向喷口的可控性实验配置，不是 Tesla 实车复原。** 尺寸、质量、喷力、气量、功率和轮胎接触参数全是假设。风扇近地吸力与固定方向排气共用功率；空中没有吸附力；落地后保留吸附增加的轮胎载荷，喷口只补偿轴向排气及其力矩。气罐降压、阀滞后、耗气和实际接触都参与计算。

成功须完成目标动作，且没有车身触地或超限冲击，随后连续 1 秒至少三轮接触、倾角 <8°、车速 <0.30 m/s、角速 <0.20 rad/s；原地任务还限水平漂移 1.5 m。轮胎是圆滑接触几何，未模拟真实橡胶与悬架。`pos` 是车体参考点；80 kg 车轮使整车质心在该点下方约1.4 cm（标称2 t，随耗气变化），控制惯量亦为假设近似。成功不是实车安全证明。

```sh
.venv/bin/python test_core.py
.venv/bin/python train.py
.venv/bin/python export_parity.py && node test_controller.mjs
.venv/bin/python run_case.py --task moving_recovery --height 8 --vx 4 --roll 150 --pitch 20 --policy final
```

`results.json` 保存同初态六路对照、每代实际评估、独立留出、SO(3) 自由初态及关口/推力折扣/降压敏感性；`policies.json` 保存参数。`world.xml` 是浏览器与 Python 共用世界，`controller.mjs` 是纯 JS 同等控制器，`baseline-replay.json` 可独立核对引擎。自由 SO(3) 取样的低高度会抬到几何刚好不穿地的最小高度 +2 cm，并记录实际初态；失败不删除。

依据：[MuJoCo 接触动力学](https://mujoco.readthedocs.io/en/stable/computation/index.html)。
