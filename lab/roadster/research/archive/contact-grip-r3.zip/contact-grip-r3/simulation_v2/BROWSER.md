# 浏览器内的物理实验

浏览器运行官方 MuJoCo 3.15.0 WebAssembly。控制周期 20 ms，每周期进行十次 2 ms 刚体、被动轮与接触积分。页面改变初态后重新调用 `mj_step`，没有读取预录轨迹来决定位姿。

```js
const engine = await loadEngine('./vendor/mujoco/mujoco.js');
const sim = await createSimulation(config, parameters, initialCase, {
  engine, xml: worldXml, policyId: 'final'
});
const frame = sim.step(1); // 一个控制周期
sim.applyImpulse([0, 2000, 0]); // 下一物理子步施加于系统质心，单位 N·s
sim.reset(newCase, initialParameters, {policyId: 'untuned'});
sim.dispose();
```

`initialCase` 包含 `task`、`pos`、`quat`（w,x,y,z）、世界坐标 `vel`、机体坐标 `omega`；可设 `mass`、`fuel`、`thrust_scale`、`disabled_nozzles` 和 `delivery_mode`。穿地初态会报错。`policyId: 'no_control'` 禁用喷气与风机。

`snapshot()` 返回真实位姿、接触、连续稳定时长、每个口的阀门开度和实际力、剩余气量、风机功率、目标与控制误差。`done` 表示试验结束；`status` 保留失败原因。`advance(command,fanCommand)` 供机械对照测试使用，不进行任务判定。

运行 `node simulation_v2/test-browser-runtime.mjs` 同时执行 Python 原生参考与 WASM。检查自由落体、单口、风机、低气量、禁用喷口、被动轮，以及三种任务的初始和人工控制基线；结果写入 `browser-verification.json`。使用 `MUJOCO_JS=file:///…/mujoco.js` 指定引擎文件。

contact-grip-r3 第 20 代最终策略已通过 18 项对照：整体最大状态差约 `1.51e-10`，最终策略自身最大差约 `3.56e-15`。三项目标和自由姿态样例成功，低高度倒置样例仍碰地失败。最终策略落稳后风机下压力约 1221.5 N，MuJoCo 法向载荷增加约 1221.5 N；喷口竖直合力约 12.3 N，没有抵消吸附。报告包含源码与策略哈希。

限制：这是平地、假设 12 个喷口的可控性实验；外观网格不参与碰撞。不能据此认定 Tesla 实车布局或硬件能力。
