# Roadster 研究与训练

先看[物理与证据](physics.md)，再看[尺度估计](measurement.md)和[新版物理试验](simulation-v2.md)。

- [素材](media.md)：两段1080p视频、10张高清帧、官方图片。
- [外形参考](model-reference.md)：官网多视角与原型区别，车模比较依据。
- [风扇专利](fan-patents.md)：涵道风扇、裙边、吸附与推力。
- [视频计划](content-plan.md)：90秒分镜。
- [原文入口](transcript-index.md) / [四版本评审](cross-review.md)。

图像尺寸依据、质量假设与真实训练数据分别标注。仿真结果不等于Tesla实车性能。初版长文留在archive，不再作为阅读入口。

新版页面为 `lab.html`，车模三版比较为 `model.html`。旧版训练保留在 `training.html`，其首次接触验收已由新版替代。

[着色模型、排气与控制时序](materials-and-control.md)：Kimi + Codex材质、当前理想状态反馈、Node及浏览器耗时。
