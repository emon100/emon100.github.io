# Roadster 研究与飞行试验

- 网站源文件在 `site/dist/`，新版入口 `lab.html`，车模比较 `model.html`。
- 原片、高清帧、官网图在 `media/`；来源与物理资料见 `research/README.md`。
- 新车模、输入依据和导出验证在 `models/`；Meshy 手动模型已去墙；此前 CLI 请求未生成。
- MuJoCo 世界、控制器、22 代学习、独立留出与审计在 `simulation_v2/`。该目录 README 给出复现方式。
- `roadster-research-package.zip` 可离线运行网站，含仿真复现代码。旧试验与中间版本留在各目录的 `archive/`。

独立任务留出最终为 40/40、40/40、36/40；宽范围自由姿态只有 24/80。尺寸、质量与 12 喷口布局均是假设，不能作为 Tesla 实车能力证明。

在线私有站：https://roadster-physics-studio.dohuuphong62.chatgpt.site/lab.html

最新着色Meshy位于 `models/meshy/materials-reviewed/roadster-meshy-colored.glb`，训练可视化已启用；传感器与耗时说明见 `research/materials-and-control.md`。
