# Roadster 研究与飞行试验

- 网站源文件在 `site/dist/`，当前入口 `lab.html`，车模比较 `model.html`。
- 原片、高清帧、官网图在 `media/`；来源见 `research/README.md`。
- 车模及导出验证在 `models/`；当前着色模型为 `models/meshy/materials-reviewed/roadster-meshy-colored.glb`。
- MuJoCo世界、控制器、训练与评估在 `simulation_v2/`，其README给出复现方式。
- `roadster-research-package.zip`为离线网站与复现代码包。

当前 `launch-coupled-r5` 完成22代CEM、4,939次训练与评估，选第20代。固定留出结果为0/40、0/40、4/40，自由姿态0/80；1 ms复算分类一致。这些初态与本轮拟合、选择无交集，但已在r4研发中使用，不能称全新盲测。

r5将滚转启动门槛缩至2–15厘米，标准动作在0.20秒发出滚转命令，仍触地失败。硬件、供气和奖励未改。尺寸、质量与喷口均为实验假设；失败不能证明物理不可行或Tesla实车能力。

[私有站入口](https://roadster-physics-studio.dohuuphong62.chatgpt.site/lab.html) · [物理与结果](research/simulation-v2.md) · [检查](research/verification.md) · [训练经验](research/training-lessons.md) · [材质与耗时](research/materials-and-control.md)

历史：[r4存档](research/archive/attitude-only-blowdown-r4.zip) · [r3存档](research/archive/contact-grip-r3.zip)。
