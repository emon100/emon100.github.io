# Roadster 研究与训练

先看[物理与证据](physics.md)、[尺度估计](measurement.md)，再看[当前试验](simulation-v2.md)、[检查结果](verification.md)与[训练经验](training-lessons.md)。

- [素材](media.md)：两段1080p视频、10张高清帧、官方图片。
- [外形参考](model-reference.md)：官网多视角与原型区别。
- [风扇专利](fan-patents.md) / [低重心依据](ev-cg-sources.md)。
- [视频计划](content-plan.md)：90秒分镜。
- [原文入口](transcript-index.md) / [四版本评审](cross-review.md)。
- [材质、排气与控制时序](materials-and-control.md)。

当前入口为 `lab.html`，车模比较为 `model.html`。r5让上升与滚转更早重叠；两项完整滚转固定留出仍各0/40，回正4/40。留出初态与本轮拟合、选择无交集，但研发中已使用过。仿真不代表Tesla实车性能，也不能由失败推出动作物理上不可行。

旧版训练在 `training.html`。历史说明、源码与结果见[r4存档](archive/attitude-only-blowdown-r4.zip)与[r3存档](archive/contact-grip-r3.zip)，不作为当前结论。
