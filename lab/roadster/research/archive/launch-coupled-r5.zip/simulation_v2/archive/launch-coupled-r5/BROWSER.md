# 浏览器物理实验 · r5

官方 MuJoCo 3.15.0 WASM 每 2 ms 积分，控制器每 20 ms 读取当前状态并更新喷口。改初态后重新计算，不用预录轨迹决定位姿。

- `frame.pos` 是整车重心。静止离地 0.50 m、前后 50:50 是假设；车壳惯性中心随气量补偿轮体质量，整车重心与惯量已做 native/WASM 对照。
- 保留竖直起降及姿态控制，没有水平速度或位置目标。风机的轴向反作用保留。
- kickflip 在离地上升段开始：清空轮胎接触、竖直速度为正，并跨过 2–15 cm 的可训练离地门槛。只改滚转启动规则，硬件、重心、供气与接触判定不变。
- 全程供气衰减：`P/P0=(m/m0)^1.2`、`Isp/Isp0=(m/m0)^0.1`，没有恒压平台。
- 允许向前滚动着陆。完成动作且无车身碰地或冲击超限后，至少三轮接触连续 1 秒；竖直速度 <0.3 m/s、侧滑 <0.3 m/s、轮胎接触滑移 <0.5 m/s、角速 <0.2 rad/s、倾角 <8°。

```js
const engine = await loadEngine('./vendor/mujoco/mujoco.js');
const sim = await createSimulation(config, parameters, initialCase, {
  engine, xml: worldXml, policyId: 'final'
});
const frame = sim.step(1); // 一个控制周期
sim.applyImpulse([0, 2000, 0]); // 下一物理子步在整车重心施加 N·s 冲量
sim.reset(newCase, parameters, {policyId: 'untuned'});
sim.dispose();
```

初态使用米、秒、弧度，`quat` 为 w,x,y,z；`vel` 为世界坐标，`omega` 为车体坐标。穿地初态和恒压供气模式会报错。`snapshot()` 返回接触、实际喷力、气量、轮速、水平冲量和控制误差；`done/status` 表示结束及原因。`allocation.requestedForceWorld` 保存控制采样时刻的世界目标力；不要用帧末姿态旋转旧的机体系目标力。初始及关闭控制时该值为零，旧录像缺少该字段时应显示“未记录”。

运行 `node simulation_v2/test-browser-runtime.mjs` 查看双引擎验收，运行 `node simulation_v2/benchmark_timing.mjs` 实测当前最终策略耗时。报告核对源码和策略哈希，r4 已归档，旧成功状态和耗时不能代表 r5。第 20 代最终策略已通过 19 项双引擎对照。标准 kickflip 在 0.20 s、离地约 9.2 cm、上升约 1.12 m/s 时开始滚转，首个控制步实际滚转力矩约 7.21 kN·m。水平目标力保持零，真实喷气受阀门延迟影响可有残差。三项标准场景仍是两项车身碰地、一项冲击超限；数值一致不代表控制成功。

这仍是假设 12 个喷口、简化轮胎和平地的实验；外观网格不参与碰撞，传感器使用理想状态。Node 耗时不保证浏览器或实车的最坏执行时间。
