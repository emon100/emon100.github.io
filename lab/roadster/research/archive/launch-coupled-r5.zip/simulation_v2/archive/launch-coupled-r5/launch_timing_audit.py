"""Reproducible old-policy/new-start-rule A/B audit, with control-sample event times."""
from pathlib import Path
import argparse, copy, hashlib, importlib.util, json, math, sys
import numpy as np
import core

HERE=Path(__file__).resolve().parent
ARCHIVE=HERE/'archive'/'attitude-only-blowdown-r4'

def module_at(path):
    spec=importlib.util.spec_from_file_location('archived_launch_core',path);mod=importlib.util.module_from_spec(spec);previous=sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode=True;spec.loader.exec_module(mod)
    finally:sys.dont_write_bytecode=previous
    return mod

def measure(mod,cfg,params,task,label):
    case=mod.default_case(task,cfg,cfg['seed']);w=mod.World(cfg);w.reset(case);policy=mod.FeedbackPolicy(params,task,case,cfg)
    takeoff=None;roll=None;apex=None;first_contact=None;previous_vz=0.;highest=case['pos'][2];status='timeout'
    dt=cfg['physics']['control_dt']
    def event(s,t):
        return {'t':float(t),'heightCG':float(s['pos'][2]),'riseAboveGroundCG':float(s['pos'][2]-cfg['vehicle']['ground_cg_height']),'riseAboveInitialCG':float(s['pos'][2]-case['pos'][2]),'verticalVelocity':float(s['vel'][2]),'pressureRatio':float(mod.delivery(w.fuel,cfg)[0]),'fuel':float(w.fuel),'wheelCount':w.contact['wheelCount'],'bodyRollRate':float(s['omega'][0])}
    for i in range(round(cfg['physics']['max_time']/dt)):
        s=w.state();t=float(w.data.time)
        if takeoff is None and w.contact['wheelCount']==0 and s['vel'][2]>0 and s['pos'][2]>case['pos'][2]+.001:takeoff=event(s,t)
        if takeoff and apex is None and previous_vz>0>=s['vel'][2]:apex=event(s,t)
        previous_vz=float(s['vel'][2]);F,T,fc=policy.command(s,w.contact);fan=mod.fan_model(s['pos'],s['R'],fc,cfg)
        wrench=np.r_[s['R'].T@F,T-s['R'].T@fan['torqueWorld']];u,allocation=w.allocate(wrench)
        started=roll is None and policy.phase=='flip'
        if started:
            roll=event(s,t);roll.update(requestedRollTorque=float(T[0]),allocatedRollTorque=float(allocation['achievedWrenchBody'][3]),realizedRollTorqueBeforeCommand=float((w.A@w.forces)[3]),gateParameter=float(params[mod.PARAMETERS.index('flip_start_clearance')]))
        post=w.advance(u,fc,{'task':task,'initialXY':case['pos'][:2],'turnComplete':bool(policy.turn_complete),'wasAirborne':bool(policy.was_airborne)})
        if started:roll['realizedRollTorqueAfterFirstControlStep']=float((w.A@w.forces)[3])
        highest=max(highest,float(post['pos'][2]))
        if takeoff and first_contact is None and (w.contact['wheelCount']>0 or w.contact['bodyContact']):first_contact=event(post,w.data.time)
        if w.any_body_contact:status='body_contact';break
        if w.hard_contact:status='hard_contact';break
        if w.stable_seconds+1e-10>=cfg['landing']['stable_seconds'] and policy.turn_complete and policy.was_airborne:status='success';break
    return {'task':task,'policy':label,'case':case,'parameters':list(map(float,params)),'takeoff':takeoff,'firstRollCommand':roll,'firstAscentApex':apex,'firstReturnContact':first_contact,'delayAfterTakeoff':float(roll['t']-takeoff['t']) if roll and takeoff else None,'rollCommandBeforeFirstApex':bool(roll and (not apex or roll['t']<apex['t'])),'observedPeakCGHeight':highest,'status':status}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--old-only',action='store_true');args=ap.parse_args()
    old=module_at(ARCHIVE/'core.py');cfg_old=old.load_config();old_p=json.loads((ARCHIVE/'policies.json').read_text());rows=[]
    for task in ['stationary_kickflip','moving_kickflip']:
        for label in ['untuned','handcrafted','final']:
            params=old_p['policies'][label]['parameters'];rows.append({'comparison':'r4_original',**measure(old,cfg_old,params,task,label)})
    report={'revision':'launch-coupled-r5','observationIntervalSeconds':.02,'takeoffDefinition':'First control observation with zero wheel contacts, upward velocity, and CG at least 1 mm above its initial height; observation precision is 20 ms.','rollDefinition':'First state-feedback command in the flip phase. Torque values are body-X torque; actual valve response is measured separately.','historicalSourceSha256':hashlib.sha256((ARCHIVE/'core.py').read_bytes()).hexdigest(),'rows':rows}
    if not args.old_only:
        comparisons={'notice':'Isolated paired replay, outside r5 training/holdout statistics. Both use the r4 learned vector; B changes only the launch gate and its clearance parameter to 0.05 m.','tasks':{}}
        cfg=core.load_config();report['currentSourceSha256']=hashlib.sha256((HERE/'core.py').read_bytes()).hexdigest()
        for task in ['stationary_kickflip','moving_kickflip']:
            for label in ['untuned','handcrafted','final']:
                params=old_p['policies'][label]['parameters'].copy();params[core.PARAMETERS.index('flip_start_clearance')]=.05
                rows.append({'comparison':'r4_parameters_with_r5_launch_gate_only',**measure(core,cfg,params,task,label)})
        for task in ['stationary_kickflip','moving_kickflip']:
            original=old_p['policies']['final']['parameters'].copy();changed=original.copy();changed[core.PARAMETERS.index('flip_start_clearance')]=.05;case=old.default_case(task,cfg_old,cfg_old['seed'])
            paired={}
            for label,mod,config,params in [('r4_late',old,cfg_old,original),('early_gate_only',core,cfg,changed)]:
                r=mod.rollout(task,params,case,config,record=True,policy_id=label);r.update(parameters=params,parameterNames=core.PARAMETERS,generation=old_p['policies']['final']['generation'],trainedUnderRevision='attitude-only-blowdown-r4',launchRule='meter_height_gate' if label=='r4_late' else 'airborne_ascending_early_gate',sourceSha256=report['historicalSourceSha256'] if label=='r4_late' else report['currentSourceSha256'])
                paired[label]=r
            comparisons['tasks'][task]=paired
        core.write_json(HERE/'launch-comparisons.json',comparisons)
        current=json.loads((HERE/'policies.json').read_text())
        if current.get('revision')=='launch-coupled-r5' and 'final' in current['policies']:
            for task in ['stationary_kickflip','moving_kickflip']:
                for label in ['untuned','handcrafted','mid','final']:
                    rows.append({'comparison':'r5_learned' if label in ['mid','final'] else 'r5_baseline',**measure(core,cfg,current['policies'][label]['parameters'],task,label)})
    core.write_json(HERE/'launch-timing-audit.json',report)
    for r in rows:
        roll=r['firstRollCommand'];takeoff=r['takeoff'];print(r['comparison'],r['task'],r['policy'],{'takeoff':takeoff['t'] if takeoff else None,'roll':roll['t'] if roll else None,'vz':roll['verticalVelocity'] if roll else None,'rise':roll['riseAboveGroundCG'] if roll else None,'pressure':roll['pressureRatio'] if roll else None,'apex':r['firstAscentApex']['t'] if r['firstAscentApex'] else None,'status':r['status']})

if __name__=='__main__':main()
