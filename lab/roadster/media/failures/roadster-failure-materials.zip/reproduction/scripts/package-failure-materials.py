from pathlib import Path
import json,hashlib,shutil,zipfile
from PIL import Image,ImageChops
ROOT=Path(__file__).resolve().parents[1];base=ROOT/'media/failures';index=json.loads((base/'index.json').read_text());qa={'status':'passed','cases':[],'limits':['Visual checks cover contact sheets and full-resolution key frames; all-frame checks cover dimensions, mapping and unchanged pixels outside annotation bands.','These are simulation failures, not documentary footage. Exterior and collision geometry differ.']}
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
for c in index['cases']:
 out=base/c['id'];r=json.loads((out/'trajectory.json').read_text());p=json.loads((out/'provenance.json').read_text());s=json.loads((out/'render-schedule.json').read_text());source=json.loads((ROOT/p['sourceFile']).read_text())['tasks']['stationary_kickflip']['comparisons'][p['policyId']]
 assert r['frames']==source['frames'];assert digest(r['frames'])==p['framesCanonicalSha256'];assert p['tailAfterFailureSeconds']>=.4
 for n,entry in enumerate(s['schedule']):
  f=r['frames'][entry['sourceIndex']];assert f['t']<=entry['outputTime']+1e-8
  a=Image.open(out/'frames'/f'{n:05d}.png').convert('RGB');b=Image.open(out/'annotated-frames'/f'{n:05d}.png').convert('RGB');assert a.size==b.size==(1080,1920)
  assert ImageChops.difference(a.crop((0,156,1080,1630)),b.crop((0,156,1080,1630))).getbbox() is None
 videos=p['rendering']['video'];assert videos['clean.mp4']['duration']==videos['annotated.mp4']['duration'];c.update({'renderStatus':'complete','outputDurationSeconds':p['rendering']['durationSeconds'],'videoFrames':s['count'],'fps':30,'width':1080,'height':1920})
 p['rendering']['captureEngine']='Existing authorized Ego TaskSpace 13, p1; direct PNG export from the actually rendered WebGL canvas.'
 p['rendering']['sourceHashes']={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in ['site/dist/failure-capture.mjs','site/dist/meshy-model.mjs','site/dist/jet-smoke.mjs','site/dist/models/meshy/roadster-meshy-colored.glb','scripts/capture-failure-frames.ego.mjs','scripts/encode-failure-videos.py']}
 (out/'provenance.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
 read=(out/'README.md').read_text().replace('（仅实际生成后提供）','').split('\n已导出：')[0];read+=f'\n已导出：1080×1920，30 fps，H.264，时长 {c["outputDurationSeconds"]:.3f} 秒，无音轨。两版共用 {s["count"]} 张底图；最后为30fps封装补齐 {p["rendering"]["finalFrameCadencePaddingSeconds"]:.3f} 秒，不是新增物理运动。\n';(out/'README.md').write_text(read)
 web=ROOT/'site/dist/media/failures'/c['id'];web.mkdir(parents=True,exist_ok=True)
 for f in ['clean.mp4','annotated.mp4','caption.srt','caption.md','README.md','provenance.json','render-schedule.json','contact-sheet.jpg']:shutil.copy2(out/f,web/f)
 qa['cases'].append({'id':c['id'],'sourceFramesExact':True,'outputFrames':s['count'],'allPngDimensions':[1080,1920],'sameTimingBothVersions':True,'unannotatedRegionPixelsIdentical':True,'sourceTailAfterFailureSeconds':p['tailAfterFailureSeconds']})
(base/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');(base/'qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n')
lines=['# 失败视频素材包','', '三例真实仿真回放，非Tesla实拍。每例含无文字与说明版，均1080×1920、30 fps、H.264、无音轨。','', '| 案例 | 内容 | 首次失败 | 源片结束 | 视频时长 |','|---|---|---:|---:|---:|']
for c in index['cases']:lines.append(f'| [{c["title"]}]({c["id"]}/README.md) | [无文字]({c["clean"]}) / [说明]({c["annotated"]}) | {c["firstFailureSeconds"]:.2f}s | {c["sourceEndSeconds"]:.2f}s | {c["outputDurationSeconds"]:.3f}s |')
lines+=['','每帧使用不晚于输出时刻的原始20ms记录，未插值姿态或重模拟。所有片段保留失败后约0.4秒；封装到30fps只补齐不足0.05秒的末帧，没有叙事停帧。两版的运动、镜头、时序完全一致，说明版仅叠加文字。','','每例的 trajectory.json、config.json、provenance.json、render-schedule.json 可复核原始状态、版本、文件/源码哈希、是否为人工开发样例及采样映射。r6是未调参开发记录，不是100代训练最终结果。','','原始PNG与说明PNG保留在本地各例 frames/、annotated-frames/。ZIP不重复收录PNG，包含6段MP4、3份轨迹、来源、字幕和复现脚本。重新渲染需原项目的Three、着色Meshy与烟雾模块；视频本身可独立播放。','','画面外壳与碰撞几何不同；烟雾只示意方向和相对强度，不是CFD。实际失败由源物理记录判断，不能仅凭外观接触判定。','','本地浏览：启动原项目 site/dist 的静态服务后打开 failure-library.html。']
(base/'README.md').write_text('\n'.join(lines)+'\n')
zip_path=base/'roadster-failure-materials.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in ['README.md','index.json','qa.json','browser-qa.json']:z.write(base/name,name)
 for c in index['cases']:
  for f in (base/c['id']).iterdir():
   if f.is_file():z.write(f,f.relative_to(base))
 for f in ['scripts/capture-failure-frames.ego.mjs','scripts/encode-failure-videos.py','scripts/build-failure-assets.py','scripts/package-failure-materials.py','site/dist/failure-capture.html','site/dist/failure-capture.mjs']:
  z.write(ROOT/f,'reproduction/'+f)
for name in ['README.md','index.json','qa.json','browser-qa.json','roadster-failure-materials.zip']:shutil.copy2(base/name,ROOT/'site/dist/media/failures'/name)
print(json.dumps({'status':'passed','zip':str(zip_path),'zipBytes':zip_path.stat().st_size,'cases':qa['cases']},ensure_ascii=False))
