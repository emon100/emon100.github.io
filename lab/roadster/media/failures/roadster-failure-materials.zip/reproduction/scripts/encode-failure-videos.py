"""Encode clean / annotated videos from the same captured PNG sequence.
Uses only recorded simulation frames. No pose interpolation or resimulation.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,math,subprocess,hashlib,sys
ROOT=Path(__file__).resolve().parents[1];base=ROOT/'media/failures'
font='/System/Library/Fonts/STHeiti Light.ttc'
F={n:ImageFont.truetype(font,n) for n in [26,30,34,40,54]}
headlines={'late-roll-start':['先升高，再开始翻转','r4 / 训练第18代'],'early-roll-low-height':['提前转，仍然太低','r5 / 训练第20代'],'high-jump-hard-landing':['飞得够高，落地仍过重','r6 / 未调参开发回放']}
notes={'late-roll-start':['起转命令：1.14 秒','尚未完成一周滚转，车身触地。'],'early-roll-low-height':['起转命令：0.20 秒；峰值CG 1.60 米','翻转尚未完成，车顶已经触地。'],'high-jump-hard-landing':['整段峰值CG 8.79 米，最终转完一周','落地冲击超限，不是平稳着陆。']}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def clock(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
for ident in sys.argv[1:] or headlines:
 out=base/ident;r=json.loads((out/'trajectory.json').read_text());prov=json.loads((out/'provenance.json').read_text());sched=json.loads((out/'render-schedule.json').read_text());files=sorted((out/'frames').glob('*.png'));assert len(files)==sched['count'],(ident,len(files),sched['count'])
 ann=out/'annotated-frames';ann.mkdir(exist_ok=True)
 for n,p in enumerate(files):
  assert p.name==f'{n:05d}.png';im=Image.open(p).convert('RGBA');assert im.size==(1080,1920)
  src=r['frames'][sched['schedule'][n]['sourceIndex']];layer=Image.new('RGBA',im.size);d=ImageDraw.Draw(layer)
  d.rounded_rectangle((40,24,1040,155),radius=18,fill=(12,23,31,224));d.text((70,38),headlines[ident][1]+' · 仿真，非实车拍摄',font=F[26],fill='#a5c7d4');d.text((68,82),headlines[ident][0],font=F[54],fill='#f0f5f7')
  d.rounded_rectangle((40,1630,1040,1880),radius=20,fill=(12,23,31,230));failed=src['t']>=prov['firstFailureSeconds']-1e-9
  d.text((72,1654),f'原始帧 {src["t"]:.2f} s   ·   CG {src["pos"][2]:.2f} m   ·   vz {src["vel"][2]:+.2f} m/s',font=F[34],fill='#e0edf1')
  d.text((72,1712),notes[ident][0],font=F[30],fill='#c4dce5');d.text((72,1760),notes[ident][1],font=F[34],fill='#ffb79d' if failed else '#e0edf1')
  d.text((72,1820),f'首次失败 {prov["firstFailureSeconds"]:.2f} s  ·  保留失败后 {prov["tailAfterFailureSeconds"]:.2f} s',font=F[26],fill='#9bb8c6')
  Image.alpha_composite(im,layer).convert('RGB').save(ann/p.name)
 for dirname,name in [('frames','clean.mp4'),('annotated-frames','annotated.mp4')]:
  if name=='clean.mp4' and (out/name).exists():continue
  subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-framerate','30','-i',str(out/dirname/'%05d.png'),'-an','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(out/name)],check=True)
 metadata={}
 for name in ['clean.mp4','annotated.mp4']:
  probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height,r_frame_rate,nb_frames,codec_name,duration','-of','json',str(out/name)]))['streams'][0];assert probe['width']==1080 and probe['height']==1920 and probe['r_frame_rate']=='30/1';assert int(probe['nb_frames'])==sched['count'];metadata[name]={'sha256':digest(out/name),'bytes':(out/name).stat().st_size,**probe}
 assert metadata['clean.mp4']['nb_frames']==metadata['annotated.mp4']['nb_frames']
 prov['rendering'].update({'status':'complete','video':metadata,'frameMappingFile':'render-schedule.json','sourceTrajectoryUnchanged':digest(out/'trajectory.json')==prov['trajectoryFileSha256'],'durationSeconds':sched['count']/30,'finalFrameCadencePaddingSeconds':round(sched['count']/30-prov['sourceEndSeconds'],6),'addedEndingFreezeSeconds':0,'annotation':'Text composited onto the exact same clean PNG sequence, without timing or crop changes.','rendererFiles':['site/dist/failure-capture.html','site/dist/failure-capture.mjs','scripts/capture-failure-frames.ego.mjs','scripts/encode-failure-videos.py']})
 (out/'provenance.json').write_text(json.dumps(prov,ensure_ascii=False,indent=2)+'\n')
 text='仿真失败回放，非Tesla实拍。'+notes[ident][0]+'。'+notes[ident][1]
 (out/'caption.srt').write_text('1\n'+clock(0)+' --> '+clock(sched['count']/30)+'\n'+text+'\n')
 print(ident,json.dumps(metadata,ensure_ascii=False),flush=True)
