// Run only after human authorization to control the existing Ego task space.
// Set globalThis.failureExportOptions before this script: {caseId, page, from, count}.
// The surrounding Ego runtime filters environment variables, so use a prepended object.
const fs=await import('node:fs/promises'),path=await import('node:path');
const opts=globalThis.failureExportOptions??{},ident=opts.caseId??'late-roll-start',from=Number(opts.from??0),count=Number(opts.count??30),root=opts.root??'/Users/emon100/IdeaProjects/rodstar',pageLabel=opts.page;
if(!pageLabel)throw Error('Set FAILURE_PAGE to the existing authorized local render page');
const task=await taskSpace(13),page=task.page(pageLabel),out=path.join(root,'media/failures',ident,'frames');await fs.mkdir(out,{recursive:true});
const info=await page.evaluate(()=>({ready:window.failureCapture?.ready,id:window.failureCapture?.caseId}));
if(!info.ready)throw Error('Authorized page must already show failure-capture.html');
if(info.id!==ident)await page.evaluate(id=>window.failureCapture.load(id),ident);
await page.waitForFunction(()=>window.failureCapture?.ready,undefined,{timeout:30000});
const meta=await page.evaluate(()=>({caseId:failureCapture.caseId,count:failureCapture.frameCount,sourceEnd:failureCapture.sourceEnd,schedule:failureCapture.schedule}));
await fs.writeFile(path.join(root,'media/failures',ident,'render-schedule.json'),JSON.stringify(meta,null,2));
const rows=[];
for(let n=from;n<Math.min(meta.count,from+count);n++){
 const exported=await page.evaluate(n=>failureCapture.exportFrame(n),n),frame=exported.meta;
 if(exported.width!==1080||exported.height!==1920)throw Error('Unexpected export size');const data=exported.png;if(!data)throw Error('Canvas export missing data');
 await fs.writeFile(path.join(out,String(n).padStart(5,'0')+'.png'),Buffer.from(data,'base64'));rows.push({outputFrame:n,sourceIndex:frame.sourceIndex,sourceT:frame.sourceT});
}
console.log({caseId:ident,from,captured:rows.length,last:rows.at(-1),output:out});
