from pathlib import Path
import json, hashlib, shutil
ROOT=Path(__file__).resolve().parents[1]
CASES=[
 ('late-roll-start','r4 · 先升高，后滚转','simulation_v2/archive/attitude-only-blowdown-r4/results.json','final',False,'米级启动门槛限制了策略空间；尚未完成一周滚转便车身触地。'),
 ('early-roll-low-height','r5 · 提前转，仍然太低','simulation_v2/archive/launch-coupled-r5/results.json','final',False,'起转提前至0.20秒，但实际峰值重心仅约1.60米，未留下足够时间完成滚转与制动。'),
 ('high-jump-hard-landing','r6 · 飞得高，落地过重','simulation_v2/archive/energy-coupled-r6-short-run/results.json','untuned',True,'未调参开发回放达到约8.79米，但接触闭合速度与冲击超过本模型验收阈值。'),
]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
index={'schemaVersion':1,'kind':'actual_simulation_failures_not_tesla_footage','fps':30,'width':1080,'height':1920,'cases':[]}
for ident,title,source,policy,manual,reason in CASES:
 src=ROOT/source;data=json.loads(src.read_text());r=data['tasks']['stationary_kickflip']['comparisons'][policy]
 p=data['tasks']['stationary_kickflip']['policies'][policy];out=ROOT/'media/failures'/ident;out.mkdir(parents=True,exist_ok=True)
 dest=out/'trajectory.json'
 if dest.exists():
  saved=json.loads(dest.read_text());assert saved['frames']==r['frames'],ident+' existing trajectory differs'
 else:
  saved={**r,'parameters':p['parameters'],'parameterNames':p['parameterNames'],'provenance':{'source':source,'sourceJsonPath':'tasks.stationary_kickflip.comparisons.'+policy,'sourceSha256':data['sourceSha256'],'controllerSha256':data['controllerSha256'],'recording':'Copied actual archived rollout frames without resimulation or interpolation.'}}
  dest.write_text(json.dumps(saved,ensure_ascii=False,separators=(',',':'))+'\n')
 failures=[f for f in r['frames'] if f['status'] in ['body_contact','hard_contact']]
 first=failures[0]['t'];end=r['frames'][-1]['t'];assert end-first>=.399,ident+' lacks 0.4s tail'
 (out/'config.json').write_text(json.dumps(data['config'],ensure_ascii=False,indent=2)+'\n')
 prov={'schemaVersion':1,'id':ident,'title':title,'revision':data['revision'],'sourceFile':source,'sourceFileSha256':sha(src),'sourceJsonPath':'tasks.stationary_kickflip.comparisons.'+policy,'coreSourceSha256':data['sourceSha256'],'controllerSourceSha256':data['controllerSha256'],'policyId':policy,'generation':p.get('generation'),'manualDevelopmentOrUntuned':manual,'campaignComplete':data['status']=='complete','note':'The r6 untuned example is a frozen engineering baseline from an interrupted short campaign, not a trained final policy.' if manual else 'Frozen final parameter policy of this historical campaign.','frames':len(r['frames']),'framesCanonicalSha256':digest(r['frames']),'trajectoryFileSha256':sha(dest),'firstFailureSeconds':first,'sourceEndSeconds':end,'tailAfterFailureSeconds':round(end-first,6),'sourceControlStepSeconds':data['config']['physics']['control_dt'],'status':r['status'],'peakCGHeightMeters':r['metrics']['peakHeight'],'reason':reason,'rendering':{'source':'recorded state frames only','sampling':'last recorded frame at or before n/30 seconds; no pose interpolation or resimulation','sourceFrameClockResolutionSeconds':.02,'requestedOutput':[1080,1920,30],'addedEndingFreezeSeconds':0,'audio':'none','visualNotes':'Same colored Meshy exterior and illustrative exhaust as the lab. Exhaust is not CFD. Camera/lighting do not feed back into physics. Visual exterior differs from collision proxy.','rights':'Local simulation rendering and user-provided/generated model assets; not Tesla documentary footage. Preserve asset provenance when reusing.'}}
 (out/'provenance.json').write_text(json.dumps(prov,ensure_ascii=False,indent=2)+'\n')
 (out/'caption.md').write_text(f'# {title}\n\n{reason}\n\n仿真回放，非Tesla实拍。版本 {data["revision"]}；'+('未调参开发样例，不能称为训练最终结果。' if manual else f'历史训练第{p.get("generation")}代。')+f'\n\n首次失败 {first:.2f} 秒，保留至 {end:.2f} 秒；峰值CG {r["metrics"]["peakHeight"]:.3f} 米。\n')
 (out/'README.md').write_text(f'# {title}\n\n- `trajectory.json`：原记录逐帧姿态、位置、力与接触，无插值、无重模拟。\n- `config.json`：源回放的世界配置。\n- `provenance.json`：原文件、源码和帧哈希，版本与失败时刻。\n- `caption.md`：可用的简短说明。\n- `clean.mp4`：无说明文字的竖屏版（仅实际生成后提供）。\n- `annotated.mp4`：同一视频加文字与状态读数（仅实际生成后提供）。\n\n{reason}\n\n此素材是本项目的数值试验，不是Tesla实拍，也不是实车事故。画面外壳与接触几何不同；烟雾只示意喷口方向和相对强度。\n')
 web=ROOT/'site/dist/media/failures'/ident;web.mkdir(parents=True,exist_ok=True)
 for f in ['trajectory.json','config.json','provenance.json']:shutil.copy2(out/f,web/f)
 index['cases'].append({'id':ident,'title':title,'revision':data['revision'],'reason':reason,'firstFailureSeconds':first,'sourceEndSeconds':end,'peakCGHeightMeters':r['metrics']['peakHeight'],'trajectory':ident+'/trajectory.json','provenance':ident+'/provenance.json','clean':ident+'/clean.mp4','annotated':ident+'/annotated.mp4','renderStatus':'pending'})
(ROOT/'media/failures/index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
(ROOT/'site/dist/media/failures/index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{'id':x['id'],'failure':x['firstFailureSeconds'],'end':x['sourceEndSeconds']} for x in index['cases']],ensure_ascii=False))
