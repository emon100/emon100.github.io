"""State-driven recovery prototype. No commanded poses; all forces use the frozen r6 world."""
from pathlib import Path
import sys, math, copy
import numpy as np
from scipy.optimize import linprog
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent/'baseline_r6'))
import core

DEFAULT_GUIDANCE={'tilt_rate_cap':4.,'tilt_angle_gain':4.,'tilt_rate_gain':10.,'capacity_fraction':.55,'angular_acceleration_cap':15.,'angular_brake_cap':12.,'early_tilt_rate':.15,'landing_time_reserve':.65,'yaw_rate_cap':1.8,'yaw_angle_gain':2.5,'yaw_rate_gain':6.,'yaw_start_tilt_deg':35.,'yaw_speed_deadband':.5,'descent_speed':2.5,'descent_acceleration_cap':3.,'vertical_speed_gain':5.5,'touchdown_speed':.12,'ground_margin':.15,'boost_speed_cap':10.,'boost_support_ratio':1.4,'yaw_hold_clearance':1.2}


def wrap(a):return (a+math.pi)%(2*math.pi)-math.pi

def tilt_axis(R,old=None):
    n=R[:,2];axis=np.cross(n,[0.,0.,1.]);norm=float(np.linalg.norm(axis));angle=math.acos(np.clip(n[2],-1,1))
    if norm>1e-6:axis/=norm
    else:
        axis=old.copy() if old is not None else -R[:,0].copy();axis[2]=0.;axis/=max(float(np.linalg.norm(axis)),1e-12)
    return axis,angle


def local_capacity(s,cfg,axis):
    A=core.wrench_matrix(core.nozzle_layout(cfg));pressure,_=core.delivery(s['fuel'],cfg);limits=np.array([n['maxForce'] for n in core.nozzle_layout(cfg)])*pressure*s['thrustScale'];R=s['R'];J=core.unit_inertia(cfg)*s['mass']
    for i,n in enumerate(core.nozzle_layout(cfg)):
        if n['id'] in s['disabledNozzles']:limits[i]=0.
    body_axis=R.T@axis;result={}
    for name,sign in [('accelerate',1.),('brake',-1.)]:
        target=sign*J*body_axis*1e6;force=core.allocate_fixed_nozzles(np.r_[np.zeros(3),target],limits,cfg);alpha=R@((A@force)[3:]/J);result[name]=max(0.,float(np.dot(alpha,sign*axis)))
    vertical=A@core.allocate_fixed_nozzles(np.r_[R.T@np.array([0.,0.,1e6]),np.zeros(3)],limits,cfg);result['vertical']=max(0.,float((R@vertical[:3])[2]));return result


def rotation_time(angle,speed,cap,accel,brake):
    if accel<1e-6 or brake<1e-6:return 99.
    delay=0.
    if speed<0:delay=-speed/accel;angle+=speed*speed/(2*accel);speed=0.
    speed=min(speed,cap);aa=max(0.,(cap*cap-speed*speed)/(2*accel));bb=cap*cap/(2*brake)
    if aa+bb<=angle:return delay+(cap-speed)/accel+(angle-aa-bb)/max(cap,.01)+cap/brake
    peak=math.sqrt(max(0.,(2*angle*accel*brake+brake*speed*speed)/(accel+brake)))
    return delay+max(0.,peak-speed)/accel+peak/brake


def tilt_path_floor(R,axis,angle,cfg):
    # An assumed shortest tilt arc, not an exact future motion prediction.
    return max(core.geometry_minimum_cg(core.qmat(core.axis_q(axis,angle*f))@R,cfg) for f in np.linspace(0,1,9))+.10


class RecoveryPolicy(core.FeedbackPolicy):
    guidance=DEFAULT_GUIDANCE
    def __init__(self,parameters,task,case,cfg):
        super().__init__(parameters,task,case,cfg);self.g=copy.deepcopy(type(self).guidance);self.axis=None;self.reserve_released=False;self.target_yaw=self.yaw
    def command(self,s,contact):
        if self.task!='moving_recovery':return super().command(s,contact)
        g=self.g;R=s['R'];J=core.unit_inertia(self.cfg)*s['mass'];omega_world=R@s['omega'];axis,tilt=tilt_axis(R,self.axis);self.axis=axis.copy();yaw=math.atan2(R[1,0],R[0,0]);horizontal_speed=float(np.linalg.norm(s['vel'][:2]))
        if horizontal_speed>g['yaw_speed_deadband']:
            velocity_yaw=math.atan2(s['vel'][1],s['vel'][0]);choices=[velocity_yaw,wrap(velocity_yaw+math.pi)];self.target_yaw=min(choices,key=lambda a:abs(wrap(a-self.target_yaw)))
        yaw_error=wrap(self.target_yaw-yaw);toward=float(np.dot(omega_world,axis));caps=local_capacity(s,self.cfg,axis);accel=min(g['angular_acceleration_cap'],g['capacity_fraction']*caps['accelerate']);brake=min(g['angular_brake_cap'],g['capacity_fraction']*caps['brake']);delay=self.cfg['physics']['control_dt']+self.cfg['actuators']['lag_seconds']
        stop_angle=max(toward,0.)**2/(2*max(brake,.01))+max(toward,0.)*delay;turn_time=rotation_time(tilt,toward,g['tilt_rate_cap'],accel,brake);floor=tilt_path_floor(R,axis,tilt,self.cfg);gravity=self.cfg['physics']['gravity'];z=float(s['pos'][2]);vz=float(s['vel'][2]);discriminant=vz*vz+2*gravity*(z-floor);coast_time=max(0.,(vz+math.sqrt(discriminant))/gravity) if discriminant>=0 else 0.;required_time=turn_time+g['landing_time_reserve']+.35*abs(yaw_error)/g['yaw_rate_cap'];gap=z-core.geometry_minimum_cg(R,self.cfg)
        if coast_time>=required_time:self.reserve_released=True
        build_reserve=not self.reserve_released and tilt>math.radians(g['yaw_start_tilt_deg']) and caps['vertical']>g['boost_support_ratio']*s['mass']*gravity
        command_rate=min(g['tilt_rate_cap'],g['tilt_angle_gain']*tilt,math.sqrt(2*max(brake,0.)*tilt))
        if build_reserve:command_rate=min(command_rate,g['early_tilt_rate'])
        desired_omega=axis*command_rate;omega_tilt=omega_world.copy();omega_tilt[2]=0.;alpha_tilt=g['tilt_rate_gain']*(desired_omega-omega_tilt);along=float(np.dot(alpha_tilt,axis));brake_guard=toward>.2 and stop_angle>tilt
        if brake_guard:along=min(along,-brake)
        along=float(np.clip(along,-brake,accel));alpha_tilt+=axis*(along-float(np.dot(alpha_tilt,axis)))
        yaw_weight=float(np.clip((math.cos(tilt)-math.cos(math.radians(g['yaw_start_tilt_deg'])))/(1-math.cos(math.radians(g['yaw_start_tilt_deg']))),0.,1.));yaw_caps=local_capacity(s,self.cfg,np.array([0.,0.,1.]));yaw_brake=min(g['angular_brake_cap'],g['capacity_fraction']*yaw_caps['brake']);yaw_speed=math.copysign(min(g['yaw_rate_cap'],g['yaw_angle_gain']*abs(yaw_error),math.sqrt(2*yaw_brake*abs(yaw_error))),yaw_error) if abs(yaw_error)>1e-9 else 0.;yaw_alpha=yaw_weight*g['yaw_rate_gain']*(yaw_speed-omega_world[2]);yaw_alpha=float(np.clip(yaw_alpha,-yaw_brake,yaw_brake));alpha_world=alpha_tilt+np.array([0.,0.,yaw_alpha])
        rate=float(np.linalg.norm(s['omega']));self.peak_height=max(self.peak_height,z);rel=self.base.T@R;roll=math.atan2(-rel[1,2],rel[2,2]);self.turn_angle+=wrap(roll-self.previous_roll);self.previous_roll=roll
        if self.phase=='recover' and tilt<math.radians(12) and rate<.65:self.phase='land';self.turn_complete=True
        if self.phase=='land' and contact['wheelCount']>=3 and tilt<math.radians(10):self.phase='settle'
        target_vz=None;vertical_mode='coast';force_z=0.;net_vertical_capacity=caps['vertical']/s['mass']-gravity
        if build_reserve:
            target_vz=min(g['boost_speed_cap'],max(2.,(floor-z+.5*gravity*required_time**2)/max(required_time,.1)+.5));force_z=s['mass']*(gravity+g['vertical_speed_gain']*(target_vz-vz));vertical_mode='build_recovery_time'
        elif tilt<math.radians(30):
            reserve=g['ground_margin']+max(0.,-vz)*2*delay;decel=min(g['descent_acceleration_cap'],max(.1,.5*net_vertical_capacity));available=max(0.,gap-reserve);target_vz=-min(g['descent_speed'],math.sqrt(2*decel*available)+g['touchdown_speed']);feedforward=decel if available>.02 and -g['descent_speed']<target_vz<-.2 and vz<-.2 else 0.;vertical_mode='landing_brake'
            if abs(yaw_error)>.25 and gap<g['yaw_hold_clearance'] and tilt<math.radians(15):target_vz=min(2.,2*(g['yaw_hold_clearance']-gap));feedforward=0.;vertical_mode='yaw_clearance_hold'
            force_z=s['mass']*(gravity+g['vertical_speed_gain']*(target_vz-vz)+feedforward)
        elif coast_time<required_time:
            force_z=s['mass']*gravity;vertical_mode='available_support_while_turning'
        if self.phase=='settle':force_z=0.;alpha_world*=.2;vertical_mode='settle'
        force=np.array([0.,0.,force_z]);torque=J*(R.T@alpha_world)+np.cross(s['omega'],J*s['omega']);P=J*self.p['recovery_attitude_gain']*core.rot_error(s['quat'],core.axis_q([0,0,1],self.target_yaw));D=-J*self.p['attitude_rate_gain']*s['omega'];gyro=np.cross(s['omega'],J*s['omega']);correction=torque-P-D-gyro
        self.goal={'phase':self.phase,'targetTilt':0.,'turnRemaining':tilt,'targetVerticalSpeed':target_vz,'horizontalControl':'zero_world_horizontal_force; yaw may use velocity direction','turnAngle':self.turn_angle,'turnComplete':self.turn_complete,'targetYaw':self.target_yaw,'targetYawAxisAllowsBackwardRolling':True,'commandTiltRate':command_rate,'tiltStopAngle':stop_angle,'tiltBrakeMargin':tilt-stop_angle,'tiltBrakeGuard':brake_guard,'availableTiltDeceleration':brake,'estimatedTiltTime':turn_time,'availableCoastTime':coast_time,'requiredRecoveryTime':required_time,'pathGeometryFloor':floor,'geometryMinimumCG':core.geometry_minimum_cg(R,self.cfg),'geometryClearance':gap,'verticalMode':vertical_mode,'reserveReleased':self.reserve_released,'verticalForceCapacity':caps['vertical'],'verticalNetAccelerationCapacity':net_vertical_capacity,'yawWeight':yaw_weight,'yawError':yaw_error,'commandYawRate':yaw_speed,'PDProportionalTorque':P.tolist(),'PDDampingTorque':D.tolist(),'PDIntegralTorque':[0.,0.,0.],'gyroscopicTorque':gyro.tolist(),'governorCorrectionTorque':correction.tolist(),'attitudeTorqueRequest':torque.tolist(),'horizontalForceTarget':[0.,0.],'predictionNotice':'Local constant-acceleration braking and assumed shortest tilt arc; ignores future control changes and is not full MPC.'}
        self.error={'tilt':tilt,'angularSpeed':rate,'verticalSpeed':vz,'horizontalSpeed':horizontal_speed,'stationaryDistance':float(np.linalg.norm(s['pos'][:2]-self.initial_xy)),'apexShortfall':0.,'yaw':yaw_error}
        return force,torque,self.p['landing_fan'] if self.phase=='settle' else 0.


class RecoveryWorld(core.World):
    def allocate(self,wrench):
        pressure,_=core.delivery(self.fuel,self.cfg);limits=self.fmax*pressure*self.thrust_scale
        for i,n in enumerate(self.nozzles):
            if n['id'] in self.disabled:limits[i]=0.
        s=self.state();R=s['R'];J=core.unit_inertia(self.cfg)*s['mass'];gyro=np.cross(s['omega'],J*s['omega']);alpha_world=R@((np.asarray(wrench[3:])-gyro)/J);yaw_alpha=np.array([0.,0.,alpha_world[2]]);tilt_alpha=alpha_world-yaw_alpha;tilt_torque=J*(R.T@tilt_alpha)+gyro;yaw_torque=J*(R.T@yaw_alpha)
        wrench=np.asarray(wrench);parts=[np.r_[np.zeros(3),tilt_torque],np.r_[wrench[:3],np.zeros(3)],np.r_[np.zeros(3),yaw_torque]];B=np.column_stack([self.A]+[-x for x in parts]);bounds=[(0.,float(x)) for x in limits]+[(0.,1.)]*3;ub=np.r_[np.ones(12),0.,0.,0.][None,:];cap=self.cfg['actuators']['total_force_max']*pressure*self.thrust_scale;solved=[]
        for i in [12,13,14]:
            objective=np.zeros(15);objective[i]=-1.;result=linprog(objective,A_eq=B,b_eq=np.zeros(6),A_ub=ub,b_ub=[cap],bounds=bounds,method='highs')
            if not result.success:raise RuntimeError(result.message)
            value=float(np.clip(result.x[i],0,1));bounds[i]=(max(0,value-1e-9),value);solved.append(value)
        result=linprog(np.r_[np.ones(12),0.,0.,0.],A_eq=B,b_eq=np.zeros(6),A_ub=ub,b_ub=[cap],bounds=bounds,method='highs')
        if not result.success:raise RuntimeError(result.message)
        forces=np.clip(result.x[:12],0,limits);ach=self.A@forces;horizontal=np.linalg.norm((R@ach[:3])[:2]);assert horizontal<1e-5,horizontal
        return np.divide(forces,limits,out=np.zeros(12),where=limits>0),{'requestedWrenchBody':wrench.tolist(),'achievedWrenchBody':ach.tolist(),'residual':(wrench-ach).tolist(),'normalizedResidual':float(np.linalg.norm(wrench-ach)/max(np.linalg.norm(wrench),1.)),'tiltScale':float(result.x[12]),'forceScale':float(result.x[13]),'yawScale':float(result.x[14]),'priority':'tilt_and_angular_braking_then_vertical_force_then_yaw_then_flow','worldHorizontalResidual':float(horizontal)}
