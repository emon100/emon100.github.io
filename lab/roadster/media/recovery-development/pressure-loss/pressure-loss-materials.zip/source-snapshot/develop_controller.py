"""Snapshot before executing development cases; never overwrite a previous iteration."""
from pathlib import Path
import sys,json,copy,shutil,hashlib,time,argparse
import numpy as np
import recovery_controller as rc
core=rc.core
HERE=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--iteration',required=True);ap.add_argument('--guidance');args=ap.parse_args();folder=HERE/'development'/args.iteration
    if folder.exists():raise SystemExit('Development iteration exists; not overwritten')
    folder.mkdir(parents=True);cfg=core.load_config();params=json.loads((HERE/'baseline_r6/policies.json').read_text())['policies']['final']['parameters'];guidance=copy.deepcopy(rc.DEFAULT_GUIDANCE)
    if args.guidance:guidance.update(json.loads(Path(args.guidance).read_text()))
    rc.RecoveryPolicy.guidance=guidance
    for path in [Path(__file__),HERE/'recovery_controller.py']:shutil.copy2(path,folder/path.name)
    core.write_json(folder/'guidance.json',guidance);core.write_json(folder/'config.json',cfg);core.write_json(folder/'parameters.json',params)
    sources={name:hashlib.sha256((folder/name).read_bytes()).hexdigest() for name in ['develop_controller.py','recovery_controller.py','guidance.json','config.json','parameters.json']}
    cases=[]
    for h in [9.,4.,7.,20.]:
        c=core.default_case('moving_recovery',cfg,88000+int(h));c['id']=f'development-governor-inverted-{h:g}';c['pos'][2]=h;cases.append(c)
    for h,angles,velocity,omega in [(9.,[150.,20.,0.],[5.,0.,-1.],[0.,0.,0.]),(12.,[120.,45.,60.],[5.,-3.,-2.],[.6,-.5,.8]),(9.,[90.,0.,0.],[5.,0.,-1.],[0.,0.,0.]),(9.,[0.,90.,0.],[5.,0.,-1.],[0.,0.,0.])]:
        c=core.default_case('moving_recovery',cfg,88100+len(cases));c.update(id=f'development-governor-attitude-{len(cases)}',pos=[0.,0.,h],quat=core.euler_q(*np.radians(angles)).tolist(),vel=velocity,omega=omega);cases.append(c)
    report={'kind':'manual_controller_development_not_training','iteration':args.iteration,'sources':sources,'baselineSourceSha256':hashlib.sha256((HERE/'baseline_r6/core.py').read_bytes()).hexdigest(),'guidance':guidance,'parameters':params,'hardwareChanged':False,'acceptanceChanged':False,'solver':'SciPy/HiGHS development only; formal native/WASM evaluation requires aligned solver','rows':[]}
    original=core.FeedbackPolicy;core.FeedbackPolicy=rc.RecoveryPolicy
    try:
        for case in cases:
            start=time.perf_counter();r=core.rollout('moving_recovery',params,case,cfg,record=True,policy_id='development_governor',world=rc.RecoveryWorld(cfg));r['elapsedWallSeconds']=time.perf_counter()-start;report['rows'].append(r);core.write_json(folder/'results.json',report)
            print(json.dumps({'case':case['id'],'status':r['status'],'complete':r['metrics']['turnComplete'],'peak':r['metrics']['peakHeight'],'gasUsed':r['metrics']['fuelUsed'],'closing':r['metrics']['maxContactClosingSpeed'],'normal':r['metrics']['maxTotalContactForce'],'wallSeconds':r['elapsedWallSeconds']}),flush=True)
    finally:core.FeedbackPolicy=original

if __name__=='__main__':main()
