from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageChops
import json,subprocess,hashlib,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'media/recovery-development/pressure-loss';r=json.loads((out/'trajectory.json').read_text());p=json.loads((out/'provenance.json').read_text());cfg=json.loads((out/'config.json').read_text());s=json.loads((out/'render-schedule.json').read_text());fs=r['frames'];images=sorted((out/'frames').glob('*.png'));assert len(images)==s['count'];ann=out/'annotated-frames';ann.mkdir(exist_ok=True)
font='/System/Library/Fonts/STHeiti Light.ttc';F={n:ImageFont.truetype(font,n) for n in [24,26,28,30,32,50]}
def at(t):return max((f for f in fs if f['t']<=t+1e-8),key=lambda f:f['t'])
for n,path in enumerate(images):
 f=fs[s['schedule'][n]['sourceIndex']];obs=at(f['controlObservationTime']);g=f['goal'];im=Image.open(path).convert('RGBA');assert im.size==(1080,1920);overlay=Image.new('RGBA',im.size);d=ImageDraw.Draw(overlay)
 d.rounded_rectangle((40,16,1040,142),radius=18,fill=(12,23,31,226));d.text((68,28),'开发001 · 原始仿真记录 · 非实车拍摄',font=F[26],fill='#a5c7d4');d.text((66,74),'回正后，缓冲能力不足',font=F[50],fill='#f0f5f7')
 d.rounded_rectangle((40,1630,1040,1888),radius=20,fill=(12,23,31,232));d.text((68,1652),f'原始帧 {f["t"]:.2f} s  ·  CG {f["pos"][2]:.2f} m  ·  vz {f["vel"][2]:+.2f} m/s',font=F[30],fill='#e0edf1')
 d.text((68,1700),f'气体 {f["fuel"]:.2f} kg  ·  记录气压 {f["pressureScale"]*100:.2f}%（初始=100%）',font=F[30],fill='#c4dce5')
 d.text((68,1748),f'容量观测 {obs["t"]:.2f} s：可达 {g["verticalForceCapacity"]/1000:.2f} / 重量 {obs["mass"]*cfg["physics"]["gravity"]/1000:.2f} kN',font=F[28],fill='#c4dce5')
 if f['status']=='hard_contact':note='触地冲击超限；后续停稳也不能改判成功'
 elif f['t']>=p['uprightAndSlow']['t'] and g['verticalNetAccelerationCapacity']<0:note='可达升力已低于重量，无法继续向上减速'
 elif f['t']>=p['uprightAndSlow']['t']:note='已回正并刹转，托举下降持续耗气'
 else:note='倒置起步，建立回正时间并降低角速度'
 d.text((68,1810),note,font=F[32],fill='#ffb79d' if (f['t']>=p['uprightAndSlow']['t'] and g['verticalNetAccelerationCapacity']<0) or f['status']=='hard_contact' else '#d7e7d4')
 result=Image.alpha_composite(im,overlay).convert('RGB');assert ImageChops.difference(im.convert('RGB').crop((0,143,1080,1630)),result.crop((0,143,1080,1630))).getbbox() is None;result.save(ann/path.name)
for folder,name in [('frames','clean.mp4'),('annotated-frames','annotated.mp4')]:
 if name=='clean.mp4' and (out/name).exists():continue
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-framerate','30','-i',str(out/folder/'%05d.png'),'-an','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(out/name)],check=True)
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest();videos={}
for name in ['clean.mp4','annotated.mp4']:
 probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height,codec_name,r_frame_rate,nb_frames,duration','-of','json',str(out/name)]))['streams'][0];assert (probe['width'],probe['height'],probe['r_frame_rate'],int(probe['nb_frames']))==(1080,1920,'30/1',s['count']);videos[name]={**probe,'sha256':sha(out/name),'bytes':(out/name).stat().st_size}
assert videos['clean.mp4']['duration']==videos['annotated.mp4']['duration'];assert sha(out/'trajectory.json')==p['trajectoryFileSha256']
p['rendering'].update({'status':'complete','videos':videos,'frameMappingFile':'render-schedule.json','sourceTrajectoryUnchanged':True,'durationSeconds':s['count']/30,'finalFrameCadencePaddingSeconds':s['count']/30-p['sourceEndSeconds'],'sameTimingBothVersions':True,'unannotatedPixelsIdentical':True,'captureEngine':'Authorized existing Ego TaskSpace13, p1; direct WebGL canvas PNG export.','sourceHashes':{name:sha(ROOT/name) for name in ['site/dist/recovery-capture.mjs','site/dist/meshy-model.mjs','site/dist/jet-smoke.mjs','site/dist/models/meshy/roadster-meshy-colored.glb','scripts/recovery-capture-frames.ego.mjs','scripts/recovery-capture-encode.py']}});(out/'provenance.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
# SRT is separate editorial text; trajectory and video clock are unchanged.
def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
end=s['count']/30;subs=[(0,1.52,'开发001：9米倒置回正。真实仿真，非实车拍摄。'),(1.52,4.64,'姿态已经回正并刹转；持续托举下降仍在耗气。'),(4.64,4.88,'记录中的可达升力已低于重量。'),(4.88,end,'触地冲击力超限。终态仍剩71.85kg气体，记录气压仅初始的21.37%。')];(out/'caption.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(a)} --> {stamp(b)}\n{text}' for i,(a,b,text) in enumerate(subs))+'\n')
(out/'caption.md').write_text('# 开发001：回正后缓冲能力不足\n\n1.52秒已回正并刹转，但持续托举下降仍消耗气体。4.86秒的控制观察中，可达竖直力15.729665756 kN，小于当时重量17.787415039 kN；车辆仍在下落。4.88秒首次冲击超限。\n\n源末5.30秒剩71.852755960 kg，记录压力比例0.213680421；5.28秒的容量观察为15.385150909 kN、重量17.774284074 kN。容量与帧末实际喷力是不同量，观察相差20 ms。\n\n最大法向冲击384.861759307 kN超过7倍车重阈值；最大接触闭合速度1.211720993 m/s本身未超过1.6 m/s。不能把失败改写成“气体耗尽”或“接触速度超限”。\n\n开发001不是最终修复，不是训练最终策略，也不是Tesla实拍。\n')
(out/'README.md').write_text('# 开发001 · 气压下降失败素材\n\n[无文字版](clean.mp4) · [说明版](annotated.mp4) · [字幕](caption.srt) · [精确数值说明](caption.md) · [来源与哈希](provenance.json)\n\n两版均1080×1920、30fps、H.264、无音轨，使用同一160张底图，时长5.333333秒。保留0–5.30秒原轨迹，其中首次失败4.88秒，尾部0.42秒；仅为30fps封装补齐0.033333秒末帧，没有新增物理运动。\n\n原轨迹266帧从 simulation_v3/development/001/results.json 的 rows[0]复制。未插值姿态、未重模拟；每输出帧选不晚于该输出时刻的原始20ms帧。相机只跟随实际水平位移，竖直取景固定。模型外观与碰撞体不同，烟雾是方向/强度示意。\n\n这是人工控制器开发001的失败，不是最终修复，也不是实车。source-snapshot保留当时源码、参数、配置与结果，原始数值和哈希可复核。\n')
# Keyframe contact sheet uses actual captured frames.
ids=sorted(set([0,22,45,60,90,120,146,159]));sheet=Image.new('RGB',(1080,1020),'#142028');draw=ImageDraw.Draw(sheet)
for j,n in enumerate(ids):
 im=Image.open(images[n]);im.thumbnail((270,480));x=j%4*270;y=j//4*510;sheet.paste(im,(x,y));draw.text((x+6,y+483),f'{n/30:.2f}s',font=F[24],fill='white')
sheet.save(out/'contact-sheet.jpg',quality=93)
web=ROOT/'site/dist/media/recovery-development/pressure-loss';web.mkdir(parents=True,exist_ok=True)
for name in ['clean.mp4','annotated.mp4','provenance.json','render-schedule.json','caption.srt','caption.md','README.md','contact-sheet.jpg']:shutil.copy2(out/name,web/name)
print(json.dumps({'videos':videos,'sourceUnchanged':True,'frames':s['count'],'duration':end},ensure_ascii=False),flush=True)
