from pathlib import Path
import json,hashlib,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'media/recovery-development/pressure-loss';p=json.loads((out/'provenance.json').read_text());r=json.loads((out/'trajectory.json').read_text());s=json.loads((out/'render-schedule.json').read_text());source=ROOT/p['sourceFile'];original=json.loads(source.read_text())['rows'][0];assert r['frames']==original['frames'];assert r['metrics']==original['metrics'];assert p['tailAfterFailureSeconds']>=.4
for row in s['schedule']:
 f=r['frames'][row['sourceIndex']];assert f['t']<=row['outputTime']+1e-8
snap=out/'source-snapshot'
for f in source.parent.rglob('*'):
 if f.is_file() and f.suffix in ['.py','.json','.xml','.txt']:
  to=snap/f.relative_to(source.parent);to.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,to)
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
manifest={str(f.relative_to(snap)):sha(f) for f in snap.rglob('*') if f.is_file()};(out/'source-snapshot-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
qa={'status':'passed','sourceFramesExact':True,'sourceMetricsExact':True,'sourceFrames':len(r['frames']),'outputFrames':s['count'],'sameTimingBothVersions':True,'unannotatedPixelsIdentical':True,'output':[1080,1920,30],'firstFailureSeconds':p['firstFailureSeconds'],'sourceTailSeconds':p['tailAfterFailureSeconds'],'criterion':'normal_contact_force_exceeded; closing_speed_did_not_exceed_limit','sourceSnapshotFiles':len(manifest),'browserVerificationFile':'browser-qa.json','visualCheck':'Full-resolution peak/impact samples and contact sheet reviewed; no trajectory interpolation.'};(out/'qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n')
zip_path=out/'pressure-loss-materials.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in ['README.md','caption.md','caption.srt','config.json','trajectory.json','provenance.json','render-schedule.json','source-snapshot-sha256.json','qa.json','browser-qa.json','contact-sheet.jpg','clean.mp4','annotated.mp4']:
  if (out/name).exists():z.write(out/name,name)
 for f in snap.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(out))
 for name in ['scripts/recovery-capture-assets.py','scripts/recovery-capture-frames.ego.mjs','scripts/recovery-capture-encode.py','scripts/recovery-capture-package.py','site/dist/recovery-capture.html','site/dist/recovery-capture.mjs']:z.write(ROOT/name,'reproduction/'+name)
web=ROOT/'site/dist/media/recovery-development/pressure-loss'
for name in ['qa.json','source-snapshot-sha256.json','pressure-loss-materials.zip']:
 shutil.copy2(out/name,web/name)
if (out/'browser-qa.json').exists():shutil.copy2(out/'browser-qa.json',web/'browser-qa.json')
with zipfile.ZipFile(zip_path) as z:assert z.testzip() is None
print(json.dumps({'zip':str(zip_path),'bytes':zip_path.stat().st_size,'qa':qa},ensure_ascii=False))
